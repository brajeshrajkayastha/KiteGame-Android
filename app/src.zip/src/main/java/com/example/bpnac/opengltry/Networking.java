package com.example.bpnac.opengltry;


import android.app.Activity;
import android.content.Context;
import android.net.wifi.WifiManager;
import android.text.format.Formatter;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Networking implements Runnable{
    private final Context context;
    ServerSocket serverSocket;
    public static final int SERVERPORT = 1313;
    Socket socket = null;
    public static int noOfClients = 1;

    static public List<String> mStrings = new ArrayList<String>();

    @Override
    public void run() {
        try {
            serverSocket = new ServerSocket(SERVERPORT);
        } catch (IOException e) {
            e.printStackTrace();
        }
        while (!Thread.currentThread().isInterrupted()) {
            try {
                socket = serverSocket.accept();
                noOfClients +=1;
                CommunicationThread commThread = new CommunicationThread(socket,noOfClients);
                new Thread(commThread).start();
                abcd(noOfClients);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    public Activity activity;
    public Networking(Context context){
        this.context = context;
        this.activity = (Activity) context;
    }
public void abcd(int yourId){

    mStrings.add("User "+yourId);

    mStrings.add("User "+yourId);
    mStrings.add("User "+yourId);
    mStrings.add("User "+yourId);
    String[] strings = new String[mStrings.size()];

    ArrayAdapter adapter = new ArrayAdapter<String>(context,
            R.layout.layouthost, mStrings.toArray(strings));

    ListView listView = (ListView) activity.findViewById(R.id.PlayersListView);
    listView.setAdapter(adapter);
    try {
        String str = "{\"YourId\":\""+yourId+"\",\"YourPosition\":\"{\"x\":\""+yourId*1.2+"\",\"y\":\""+3.0+"\",\"z\":\""+yourId*1.7+"\"}\"}";
        PrintWriter out = new PrintWriter(new BufferedWriter(
                new OutputStreamWriter(socket.getOutputStream())),true);
        out.println(str);
    } catch (UnknownHostException e) {
        e.printStackTrace();
    } catch (IOException e) {
        e.printStackTrace();
    } catch (Exception e) {
        e.printStackTrace();
    }
}

    @SuppressWarnings("deprecation")
    public String getLocalIpAddress(Context context) {
        String iIPv4 = "";

        WifiManager wm = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);

        iIPv4 = Formatter.formatIpAddress(wm.getConnectionInfo().getIpAddress());

        return iIPv4;
    }

}


class CommunicationThread implements Runnable {
    private Socket clientSocket;
    private int clientId;
    private BufferedReader input;
    public CommunicationThread(Socket clientSocket, int ClientId) {
        this.clientId = ClientId;
        this.clientSocket = clientSocket;
        try {
            this.input = new BufferedReader(new InputStreamReader(this.clientSocket.getInputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void run() {
        while (!Thread.currentThread().isInterrupted()) {
            try {
                String read = input.readLine();
                Log.d("From Client no "+clientId, read);
                //updateConversationHandler.post(new updateUIThread(read));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}


class ClientThread implements Runnable {
    String SERVER_IP = "172.17.1.99";

    Socket socket = null;
    @Override
    public void run() {

        try {
            InetAddress serverAddr = InetAddress.getByName(SERVER_IP);
            socket = new Socket(serverAddr, Networking.SERVERPORT);
        } catch (UnknownHostException e1) {
            e1.printStackTrace();
        } catch (IOException e1) {
            e1.printStackTrace();
        }
    }

    public void onClick(View view) {
        try {
            String str = "Latto it worked";
            PrintWriter out = new PrintWriter(new BufferedWriter(
                    new OutputStreamWriter(socket.getOutputStream())),true);
            out.println(str);
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

class misc_works{
    public void Fetch_clientdata(String jsonStr){
        if (jsonStr != null) {
            try {
                JSONObject jsonObj = new JSONObject(jsonStr);

                // Getting JSON Array node
                JSONArray PlayerData = jsonObj.getJSONArray("ClientData");

                // looping through All Contacts
                for (int i = 0; i < PlayerData.length(); i++) {
                    JSONObject c = PlayerData.getJSONObject(i);

                    JSONObject PlayerPosition = c.getJSONObject("MyPos");
                    String PlayerPosX = PlayerPosition.getString("CenterPosX");
                    String PlayerPosY = PlayerPosition.getString("CenterPosY");
                    String PlayerPosZ = PlayerPosition.getString("CenterPosZ");
                    JSONArray KitePosition = c.getJSONArray("MyKitePos");
                    float[] KiteModelMatrix = new float[16];
                    KiteModelMatrix[0] = (float)KitePosition.get(0);

                    // Phone node is JSON Object
                    JSONObject phone = c.getJSONObject("phone");
                    String mobile = phone.getString("mobile");
                    String home = phone.getString("home");
                    String office = phone.getString("office");

                    // tmp hash map for single contact
                    HashMap<String, String> contact = new HashMap<>();

                }


            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

}