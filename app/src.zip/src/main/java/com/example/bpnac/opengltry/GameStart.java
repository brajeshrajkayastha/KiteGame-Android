package com.example.bpnac.opengltry;


import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.ConfigurationInfo;
import android.media.Image;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class GameStart extends Activity {
    OpenGLView openglview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setRequestedOrientation( ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE );
        setContentView(R.layout.gameview);

        //Button pause_button = new Button(this);
        //pause_button.setText("Pause");
        //addContentView(pause_button, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        ImageView right = (ImageView) findViewById(R.id.imageView4);
        ImageView left = (ImageView) findViewById(R.id.imageView3);



        right.setOnTouchListener(new View.OnTouchListener(){
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    OpenGLRenderer.clickright(true);
                } else if (e.getAction() == MotionEvent.ACTION_UP) {
                    OpenGLRenderer.clickright(false);
                }

                return true;
            }
        });

        left.setOnTouchListener(new View.OnTouchListener(){
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    OpenGLRenderer.clickleft(true);
                } else if (e.getAction() == MotionEvent.ACTION_UP) {
                    OpenGLRenderer.clickleft(false);
                }

                return true;
            }
        });

        final ActivityManager activityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        final ConfigurationInfo configurationInfo = activityManager.getDeviceConfigurationInfo();
        final boolean supportsEs2 = configurationInfo.reqGlEsVersion >= 0x20000;

        if (supportsEs2)
        {
            //return;
            openglview = (OpenGLView) findViewById(R.id.openglss);
        }
        else
        {
            return;
        }

    }

    @Override
    protected void onResume(){
        super.onResume();
        openglview.onResume();
    }
    @Override
    protected void onPause(){
        super.onPause();
        openglview.onPause();
    }

}