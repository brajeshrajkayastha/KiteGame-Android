package com.example.bpnac.opengltry;

import android.util.Log;
import android.opengl.GLES20;
import android.opengl.Matrix;

public final class Physics {

    public static void ObjectCollision(){

        float[] kite = extendsOpenGLRenderer.Kite.MVshapepredictor();
        float[] coin = extendsOpenGLRenderer.coin.MVshapepredictor();

        if(ObjectCollisioncalc(kite,coin)){
            allsdata.IsEaten=true;
        }

    }

    static int a = 0;

    public static boolean ObjectCollisioncalc(float[] obj1, float[] obj2){
        float voldiff1,voldiff2,svol1,svol2, rvol1,rvol2,distance, diff, Xcenter1, Ycenter1, Zcenter1, Xcenter2, Ycenter2, Zcenter2, rad1, rad2;

        Xcenter1=(obj1[0]+obj1[3])/2;
        Ycenter1=(obj1[1]+obj1[4])/2;
        Zcenter1=(obj1[2]+obj1[5])/2;

        Xcenter2=(obj2[0]+obj2[3])/2;
        Ycenter2=(obj2[1]+obj2[4])/2;
        Zcenter2=(obj2[2]+obj2[5])/2;

        /*
        rvol1=(obj1[0]-obj1[3])*(obj1[1]-obj1[4])*(obj1[2]-obj1[5]);
        rvol2=(obj2[0]-obj2[3])*(obj2[1]-obj2[4])*(obj2[2]-obj2[5]);

        rad1=((obj1[3]>obj1[4]&&obj1[3]>obj1[5])?obj1[3]:obj1[4]>obj1[5]?obj1[4]:obj1[5]);
        rad2=((obj2[3]>obj2[4]&&obj2[3]>obj2[5])?obj2[3]:obj2[4]>obj2[5]?obj2[4]:obj2[5]);
        //rad1=((obj1[0]>obj1[1]&&obj1[0]>obj1[2])?obj1[0]:obj1[1]>obj1[2]?obj1[1]:obj1[2]);
        //rad2=((obj2[0]>obj2[1]&&obj2[0]>obj2[2])?obj2[0]:obj2[1]>obj2[2]?obj2[1]:obj2[2]);

        svol1=(float)(4/3)*(float)Math.PI*(float)Math.pow(rad1,3);
        svol2=(float)(4/3)*(float)Math.PI*(float)Math.pow(rad1,3);

        voldiff1=svol1-rvol1;
        voldiff2=svol2-rvol2;

        //rad1= rad1-(float)Math.pow(voldiff1,1/3);
        //rad2= rad2-(float)Math.pow(voldiff2,1/3);
        */

        a=a+1;

        rad1=(((obj1[0]-obj1[3])>(obj1[1]-obj1[4])&&(obj1[0]-obj1[3])>(obj1[2]-obj1[5]))?(obj1[0]-obj1[3])/2:(obj1[1]-obj1[4])>(obj1[2]-obj1[5])?(obj1[1]-obj1[4])/2:(obj1[2]-obj1[5])/2);

        rad2=(((obj2[0]-obj2[3])>(obj2[1]-obj2[4])&&(obj2[0]-obj2[3])>(obj2[2]-obj2[5]))?(obj2[0]-obj2[3])
                /2:(obj2[1]-obj2[4])>(obj2[2]-obj2[5])?(obj2[1]-obj2[4])/2:(obj2[2]-obj2[5])/2);

        distance= (float) Math.sqrt(Math.pow((Xcenter2-Xcenter1),2)+Math.pow((Ycenter2-Ycenter1),2)+Math.pow((Zcenter2-Zcenter1),2));
        diff=distance-rad1-rad2;

        if (a>=10) {
            Log.d("difference","" + diff);
            Log.d("Radius", "R1:"+rad1+", R2:"+rad2);
            //Log.d("center:", "obj1: " + Xcenter1 + "," + Ycenter1 + "," + Zcenter1 + " Obj2: " + Xcenter2 + "," + Ycenter2 + "," + Zcenter2);
            //Log.d("distance", "" + distance + " difference" + diff + "radius1,radius2" + rad1 + "," + rad2);
            a=0;
        }

        if (diff<=0){return true;}else{return false;}

    }

    public static boolean linecollision() {

        /*
        float[] point=intersectcheck(extendsOpenGLRenderer.linedata,extendsOpenGLRenderer.linedata2);

        if(point[3]==1){
            return ((point[0]>extendsOpenGLRenderer.linedata[3]&& point[0]<extendsOpenGLRenderer.linedata[0])&&(point[1]>extendsOpenGLRenderer.linedata[4]&& point[1]<extendsOpenGLRenderer.linedata[1])&&(point[2]>extendsOpenGLRenderer.linedata[5]&& point[2]<extendsOpenGLRenderer.linedata[2])? true :false);
        }
        else{
            return false;
        }
        */

        float[] point = intersectcheck(new float[]{1,4,-2,3,8,6}, new float[]{0,4,8,6,10,-10});

        return point[3] == 1;
    }
    static float[] intersectcheck(float[] line1, float[] line2){

        float[] p1={}, p2={};
        float x1, x2, y1, y2, z1, z2;

        /*

        //YZ
        p1=new float[]{A1[1],A1[2],B1[1],B1[2]};
        p2=new float[]{A2[1],A2[2],B2[1],B2[2]};
        y1=twolineintersect(p1,p2)[0];
        z1=twolineintersect(p1,p2)[1];

        //XY
        p1=new float[]{A1[0],A1[1],B1[0],B1[1]};
        p2=new float[]{A2[0],A2[1],B2[0],B2[1]};
        x1=twolineintersect(p1,p2)[0];
        y2=twolineintersect(p1,p2)[1];

        //XZ
        p1=new float[]{A1[0],A1[2],B1[0],B1[2]};
        p2=new float[]{A2[0],A2[2],B2[0],B2[2]};
        x2=twolineintersect(p1,p2)[0];
        z2=twolineintersect(p1,p2)[1];

        float[] A1 = {line1[0],line1[1],line1[2]}, B1={line1[3],line1[4],line1[5]};
        float[] A2 = {line2[0],line2[1],line2[2]}, B2={line2[3],line2[4],line2[5]};

     */
        //YZ
        p1=new float[]{line1[1],line1[2],line1[4],line1[5]};
        p2=new float[]{line2[1],line2[2],line2[4],line2[5]};
        y1=twolineintersect(p1,p2)[0];
        z1=twolineintersect(p1,p2)[1];

        //XY
        p1=new float[]{line1[0],line1[1],line1[3],line1[4]};
        p2=new float[]{line2[0],line2[1],line2[3],line2[4]};
        x1=twolineintersect(p1,p2)[0];
        y2=twolineintersect(p1,p2)[1];

        //XZ
        p1=new float[]{line1[0],line1[2],line1[3],line1[5]};
        p2=new float[]{line2[0],line2[2],line2[3],line2[5]};
        x2=twolineintersect(p1,p2)[0];
        z2=twolineintersect(p1,p2)[1];

       return ((x1==x2 && y1==y2 && z1==z2)? new float[]{x1,y1,z1,1}: new float[]{0,0,0,0});

    }

    static float[] twolineintersect(float[] p1, float[] p2){
        float a, b, m1, m2;

        m1=(p1[3]-p1[1])/(p1[2]-p1[0]);
        m2=(p2[3]-p2[1])/(p2[2]-p2[0]);

        a=(p1[1]-p2[1]-(m1*p1[0])+(m2*p2[0]))/(m2-m1);
        b=(p1[1]+(m1*a)-(m1*p1[0]));

        //Log.d("Point:",""+x+","+y);
        return new float[]{a,b};

    }
}

